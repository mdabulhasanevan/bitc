<?php
//this is procedure of inserting data into mysql table.
$conn = mysqli_connect("localhost", "root", "", "bitc");
$MyName="evan";
$sql = "INSERT INTO registration (Name)VALUES ('$MyName')";
mysqli_query($conn, $sql)
//retriving data forom table
$myCode = "SELECT Name FROM registration";
$result = mysqli_query($conn, $myCode);
?>
