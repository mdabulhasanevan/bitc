<?php
include("connection.php");

if(isset($_POST["Save"]))
{
$MyName=$_POST["MyName"];
$Email=$_POST["Email"];
$Mobile=$_POST["Mobile"];
$sql = "INSERT INTO registration (ID, Name, Mobile,Email)
VALUES (NULL,'$MyName','$Mobile','$Email')";

	if (mysqli_query($conn, $sql)) {
	    echo "BITC New record created successfully";
	} else {
	    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

}

header("location:index2.php?msz=Saved Successfully!!");

?>