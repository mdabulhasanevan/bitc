<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="Penguins.jpg" type="image/x-icon">
<title>Login</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body style="background-color: pink">
<div style="margin:auto; width:60%;">
<form method="POST" action="#">
<table>
<caption>Student Login</caption>
	<tr>
		<td>Email</td>
		<td><input type="email" required autocomplete="on" name="Email"/></td>
	</tr>
	<tr>
		<td>Password</td>
		<td><input type="text" required autocomplete="off" name="Password"/></td>

	</tr>
		<td></td>
		<td><button type="submit" name="login">Login</button></td>
	</tr>
</table>
		
</form>
</div>

</body>
</html>

<?php
include("connection.php");
if(isset($_POST["login"]))
{
$Email=$_POST["Email"];
$Password=$_POST["Password"];

$myCode = "SELECT * FROM registration where Email='$Email' AND Password='$Password' limit 1";

$result = mysqli_query($conn, $myCode);
$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		session_start();	
		$_SESSION["ID"] = $row ['ID'];
		$_SESSION["Name"] = $row ['Name'];
		header("location:index2.php?msz=Login Successfully!!");
	}
	else
	{
		echo "Password or Email incorrect.";
	}


	}


?>