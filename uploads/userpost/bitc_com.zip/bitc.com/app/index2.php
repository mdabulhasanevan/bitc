<?php
session_start();
if(isset($_SESSION['ID']))
{

?>

<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="Penguins.jpg" type="image/x-icon">
<title>We Are BITC</title>
<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body style="background-color: pink">
	<?php
if(isset($_GET['msz']))
{
	echo $_GET['msz'];
}

	?>
<a href="logout.php">Logout</a>
<div style="margin:auto; width:60%;">
<form method="POST" action="reg.php">
<table>
<caption>Contact Book</caption>
	<tr>
		<td>Name</td>
		<td><input type="text" required autocomplete="off" name="MyName"/></td>
	</tr>
	<tr>
		<td>Mobile</td>
		<td><input type="text" required autocomplete="off" name="Mobile"/></td>
	</tr>
		<td>Email</td>
		<td><input type="email" autocomplete="off" name="Email"/></td>
	</tr>
	</tr>
		<td></td>
		<td><button type="submit" name="Save">Save</button></td>
	</tr>
</table>
		
</form>
</div>

</body>
</html>

<?php

echo $_SERVER['PHP_SELF'];
//this is for showing list
include("connection.php");
$myCode = "SELECT * FROM registration";
$result = mysqli_query($conn, $myCode);

if (mysqli_num_rows($result) > 0) {


    echo "<table width=100%>
    <caption class='Caption'>Number List</caption>
    		<tr>
    		<th>ID</th>
    		<th>Name</th>
    		<th>Mobile</th>
    		<th>Email</th>
    		<th>Action</th>
    		</tr>";
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
       echo "<tr>";
       echo "<td>" . $row['ID'].  "</td>";
       echo "<td>" . $row['Name'].  "</td>";
       echo "<td>" . $row['Mobile'].  "</td>";
       echo "<td>" . $row['Email'].  "</td>";
       echo "<td></td>";
       echo "</tr>";
    }
	echo "</table>";

} 
mysqli_close($conn);


?>


<?php
}
else
{
	header("location:login.php");
}
?>