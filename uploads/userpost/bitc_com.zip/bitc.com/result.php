<?php
$conn = mysqli_connect("localhost", "root", "", "bitc");
$myCode = "SELECT Roll, Marks, (if(Marks>=80, 4, if(Marks>=75,3.75,if(Marks>=70,3.50, if(Marks>=65,3.25,if(Marks>=60,3,if(Marks>=55,2.75,if(Marks>=50,2.50,if(Marks>=45,2.25,if(Marks>=40,2,0)))))))))) as GPA FROM result";
$result = mysqli_query($conn, $myCode);
//result show
if (mysqli_num_rows($result) > 0) {
    echo "<table width=100% border='1'>
    <caption class='Caption'>Result</caption>
    		<tr>
    		<th>Roll</th>
    		<th>Marks</th>
    		<th>GPA</th>   		
    		</tr>";
    while($row = mysqli_fetch_assoc($result)) {
       echo "<tr>";    
       echo "<td>" . $row['Roll'].  "</td>";
       echo "<td>" . $row['Marks'].  "</td>";
       echo "<td>" . $row['GPA'].  "</td>";  
       echo "</tr>";
    }
	echo "</table>";
} 
mysqli_close($conn);
?>