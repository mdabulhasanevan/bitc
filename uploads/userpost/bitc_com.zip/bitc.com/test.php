<?php
$cars = array("Volvo", "BMW", "Toyota","Honda");
$arrlength = count($cars);

echo "<ul>";

for($i=0;$i<$arrlength;$i++)
{
	echo "<li>".$cars[$i]."</li>";
}
echo "</ul>";


$age=array("Evan"=>"28","Emon"=>"23","Ria"=>"120");


foreach($age as $x => $x_value) {
    echo "Key=" . $x . ", Value=" . $x_value;
    echo "<br>";
}





?>