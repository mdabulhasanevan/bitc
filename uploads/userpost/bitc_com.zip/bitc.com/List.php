<?php
//this is for showing list
include("connection.php");
$myCode = "SELECT * FROM registration";
$result = mysqli_query($conn, $myCode);

if (mysqli_num_rows($result) > 0) {
    
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "id: " . $row["ID"]. " - Name: " . $row["Name"]. " Moblie " . $row["Mobile"]." Email " . $row["Email"]. "<br>";
    }


} 
mysqli_close($conn);


?>